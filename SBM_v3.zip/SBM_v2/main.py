# Example:
date_string = "2022-01-13"
date_object = datetime.fromisoformat(date_string)
