# cashform/urls.py
from django.contrib.auth.decorators import login_required
from .views import CashFormListView, CashFormCreateView, CashFormUpdateView, CashFormDeleteView, your_view
from .views import CashFormListView, CashFormCreateView, CashFormUpdateView, CashFormDeleteView, your_view

from django.urls import path
from .views import CashFormListView, CashFormCreateView, CashFormUpdateView, CashFormDeleteView
from django.contrib.auth.views import LogoutView

from .views import CashFormListView, CashFormCreateView, CashFormUpdateView, CashFormDeleteView, your_view
urlpatterns = [
    path('', CashFormListView.as_view(), name='cash_form_list'),
    path('create/', CashFormCreateView.as_view(), name='cash_form_create'),
    path('edit/<int:pk>/', CashFormUpdateView.as_view(), name='cash_form_edit'),
    path('delete/<int:pk>/', CashFormDeleteView.as_view(), name='cash_form_delete'),
    path('your-view/', your_view, name='your_view'),
    path('logout/', LogoutView.as_view(), name='logout'),


]

# Apply login_required to all views in urlpatterns
urlpatterns = [path(route.pattern._route, login_required(route.callback), name=route.name) for route in urlpatterns]



# urlpatterns = [
#     path('', CashFormListView.as_view(), name='cash_form_list'),
#     path('create/', CashFormCreateView.as_view(), name='cash_form_create'),
#     path('edit/<int:pk>/', CashFormUpdateView.as_view(), name='cash_form_edit'),
#     path('delete/<int:pk>/', CashFormDeleteView.as_view(), name='cash_form_delete'),
#
# ]
