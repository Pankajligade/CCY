from datetime import timezone
from django.db import models
from django.utils import timezone
import datetime
from django.contrib.auth.models import AbstractUser




# Create your models here.
# cashform/models.py

from django.db import models

class CashForm(models.Model):
    filename = models.CharField(max_length=255, blank=True, null=True, default='',editable=False)
    # filename = models.CharField(max_length=20, blank=True, editable=False)  # Add or modify the existing definition
    MONTH_CHOICES = [
        ('01', 'January'),
        ('02', 'February'),
        ('03', 'March'),
        ('04', 'April'),
        ('05', 'May'),
        ('06', 'June'),
        ('07', 'July'),
        ('08', 'August'),
        ('09', 'September'),
        ('10', 'October'),
        ('11', 'November'),
        ('12', 'December'),
    ]
    Formonth = models.CharField(max_length=2, choices=MONTH_CHOICES)
    Foryear = models.IntegerField(choices=[(year, year) for year in range(2010, 2031)])
    ReportSerialNo = models.CharField(max_length=20, null=True, blank=True)

    BranchCode = models.CharField(max_length=25, default='2001')
    BranchName = models.CharField(max_length=20)
    AccountNo = models.CharField(max_length=20)
    NameOfAccountHolder = models.CharField(max_length=55)
    TenderingPerson = models.CharField(max_length=55)
    DateOfCashTendering = models.DateField()
    DateOfDetection = models.DateField()
    COUNTOF2000CURRENCYNOTES = models.IntegerField(blank=True, null=True)
    SERIALNOOF2000CURRENCYNOTES = models.CharField(max_length=200, blank=True, null=True)
    COUNTOF1000CURRENCYNOTES = models.IntegerField(blank=True, null=True)
    SERIALNOOF1000CURRENCYNOTES = models.CharField(max_length=200, blank=True, null=True)
    COUNTOF500CURRENCYNOTES = models.IntegerField(blank=True, null=True)
    SERIALNOOF500CURRENCYNOTES = models.CharField(max_length=200, blank=True, null=True)
    COUNTOF200CURRENCYNOTES = models.IntegerField(blank=True, null=True)
    SERIALNOOF200CURRENCYNOTES = models.CharField(max_length=200, blank=True, null=True)
    COUNTOF100CURRENCYNOTES = models.IntegerField(blank=True, null=True)
    SERIALNOOF100CURRENCYNOTES = models.CharField(max_length=200, blank=True, null=True)
    COUNTOF50CURRENCYNOTES = models.IntegerField(blank=True, null=True)
    SERIALNOOF50CURRENCYNOTES = models.CharField(max_length=200, blank=True, null=True)
    COUNTOF20CURRENCYNOTES = models.IntegerField(blank=True, null=True)
    SERIALNOOF20CURRENCYNOTES = models.CharField(max_length=200, blank=True, null=True)
    COUNTOF10CURRENCYNOTES = models.IntegerField(blank=True, null=True)
    SERIALNOOF10CURRENCYNOTES = models.CharField(max_length=200, blank=True, null=True)
    COUNTOF5CURRENCYNOTES = models.IntegerField(blank=True, null=True)
    SERIALNOOF5CURRENCYNOTES = models.CharField(max_length=200, blank=True, null=True)
    TOTALCASHTENDERED = models.IntegerField(blank=True, null=True, editable=False)
    TOTALCASHDEPOSITED = models.IntegerField(blank=True, null=True)
    DETETEDAT = models.DateField(null=True, blank=True)
    POLICEINFORMED_CHOICES = [
        ('yes', 'Yes'),
        ('no', 'No'),
    ]

    POLICEINFORMED = models.CharField(
        max_length=3,
        choices=POLICEINFORMED_CHOICES,
        default='no'  # Set the default value based on your requirements
    )
    FIRFILED = models.CharField(max_length=20, blank=True, null=True)
    DATEOFFIR = models.DateField(blank=True, null=True)
    DETAILSOFFIR = models.CharField(max_length=2000, blank=True, null=True)

    ADDITIONALINFORMATION = models.CharField(max_length=2000, blank=True, null=True)
    DETECTIONPRIORITYRATING_CHOICES = [
        ('high', 'High'),
        ('medium', 'Medium'),
        ('low', 'Low'),
    ]
    DETECTIONPRIORITYRATING = models.CharField(
        max_length=10,
        choices=DETECTIONPRIORITYRATING_CHOICES
    )
    UPLOADEDBY = models.CharField(max_length=100)
    UPLOADTIME = models.DateTimeField(auto_now_add=True)
    datemodified = models.DateField(blank=True, null=True)

    def save(self, *args, **kwargs):
        # Check if filename is not set or if it is explicitly None
        if self.filename is None or not self.filename:
            # Generate filename with "CCY" and today's date "YYYYMMDD"
            today_date = timezone.now().strftime('%Y%m%d')
            self.filename = f'CCY_{today_date}'

        # Ensure that all values are not None before performing the calculation
        if (
                self.COUNTOF2000CURRENCYNOTES is not None and
                self.COUNTOF500CURRENCYNOTES is not None and
                self.COUNTOF200CURRENCYNOTES is not None and
                self.COUNTOF100CURRENCYNOTES is not None and
                self.COUNTOF50CURRENCYNOTES is not None and
                self.COUNTOF20CURRENCYNOTES is not None and
                self.COUNTOF10CURRENCYNOTES is not None and
                self.COUNTOF5CURRENCYNOTES is not None
        ):
            # Calculate TOTALCASHTENDERED before saving
            self.TOTALCASHTENDERED = self.calculate_total_cash_tendered()

        super().save(*args, **kwargs)

    def calculate_total_cash_tendered(self):
        # Ensure that all values are not None before performing the calculation
        if (
                self.COUNTOF2000CURRENCYNOTES is not None and
                self.COUNTOF500CURRENCYNOTES is not None and
                self.COUNTOF200CURRENCYNOTES is not None and
                self.COUNTOF100CURRENCYNOTES is not None and
                self.COUNTOF50CURRENCYNOTES is not None and
                self.COUNTOF20CURRENCYNOTES is not None and
                self.COUNTOF10CURRENCYNOTES is not None and
                self.COUNTOF5CURRENCYNOTES is not None
        ):
            return (
                    self.COUNTOF2000CURRENCYNOTES * 2000 +
                    self.COUNTOF500CURRENCYNOTES * 500 +
                    self.COUNTOF200CURRENCYNOTES * 100 +
                    self.COUNTOF100CURRENCYNOTES * 100 +
                    self.COUNTOF50CURRENCYNOTES * 50 +
                    self.COUNTOF20CURRENCYNOTES * 20 +
                    self.COUNTOF10CURRENCYNOTES * 10 +
                    self.COUNTOF5CURRENCYNOTES * 5
            )
        else:
            return None  # Or handle the case when s

    def __str__(self):
        return f"{self.filename} - {self.BranchName} - {self.AccountNo}"

