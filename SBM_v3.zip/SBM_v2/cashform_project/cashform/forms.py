# cashform/forms.py

from django import forms
from .models import CashForm

class CashFormForm(forms.ModelForm):
    class Meta:
        model = CashForm
        fields = '__all__'
        widgets = {
            'Formonth': forms.Select(choices=CashForm.MONTH_CHOICES),
            'DateOfCashTendering': forms.DateInput(attrs={'type': 'date'}),
            'DateOfDetection': forms.DateInput(attrs={'type': 'date'}),
            'DETETEDAT': forms.DateInput(attrs={'type': 'date'}),
            'DATEOFFIR': forms.DateInput(attrs={'type': 'date'}),
            'UPLOADTIME': forms.DateInput(attrs={'type': 'datetime-local'}),
        }
        input_formats = {
            'Formonth': ['%Y-%m'],
            'DateOfCashTendering': ['%Y-%m-%d'],
            'DateOfDetection': ['%Y-%m-%d'],
            'UPLOADTIME': ['%Y-%m-%dT%H:%M'],
        }

    def __init__(self, *args, **kwargs):
        super(CashFormForm, self).__init__(*args, **kwargs)

        # Conditionally include or exclude FIRFILED, DATEOFFIR, and DETAILSOFFIR fields
        police_informed_value = self.initial.get('POLICEINFORMED') or self.data.get('POLICEINFORMED')
        if police_informed_value == 'No':
            self.fields['FIRFILED'].widget.attrs['disabled'] = True
            self.fields['DATEOFFIR'].widget.attrs['disabled'] = True
            self.fields['DETAILSOFFIR'].widget.attrs['disabled'] = True

    def clean(self):
        cleaned_data = super().clean()

        # Add custom validation logic here
        # For example, check if required fields are filled
        if not cleaned_data.get('AccountNo'):
            self.add_error('AccountNo', 'Account number is required.')

        # Add more validation rules as needed

        return cleaned_data

