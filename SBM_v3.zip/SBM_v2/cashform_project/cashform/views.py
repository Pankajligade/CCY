from django.shortcuts import render
from django.contrib import messages
# Create your views here.
from django.views.generic import ListView


# cashform/views.py
from django.contrib.auth.decorators import login_required

from django.shortcuts import render
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from .models import CashForm
from .forms import CashFormForm
from django.contrib import messages

@login_required
def your_view(request):
    if request.method == 'POST':
        form = CashFormForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Form successfully saved!')
            return redirect('cashform_list')  # Replace with the actual name of your URL pattern
        else:
            messages.error(request, 'Form contains errors. Please correct them.')
    else:
        form = CashFormForm()

    return render(request, 'cashform/cash_form_template.html', {'form': form})


class CashFormListView(ListView):
    model = CashForm
    template_name = 'cashform/cash_form_list.html'
    context_object_name = 'cash_forms'


class CashFormCreateView(CreateView):
    model = CashForm
    form_class = CashFormForm
    template_name = 'cashform/cash_form_template.html'
    success_url = reverse_lazy('cash_form_list')


class CashFormUpdateView(UpdateView):
    model = CashForm
    form_class = CashFormForm
    template_name = 'cashform/cash_form_template.html'
    success_url = reverse_lazy('cash_form_list')


class CashFormDeleteView(DeleteView):
    model = CashForm
    template_name = 'cashform/cash_form_confirm_delete.html'
    success_url = reverse_lazy('cash_form_list')

